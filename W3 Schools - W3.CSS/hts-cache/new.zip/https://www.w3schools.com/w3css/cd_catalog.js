{
  "cd" : [
    { "title" : "Empire Burlesque", "artist" : "Bob Dylan", "price" : "10.90" },
    { "title" : "Hide your heart", "artist" : "Bonnie Tyler", "price" : "9.90" },
    { "title" : "Greatest Hits", "artist" : "Dolly Parton", "price" : "9.90" },
    { "title" : "Still got the blues", "artist" : "Gary Moore", "price" : "10.20" },
    { "title" : "Eros", "artist" : "Eros Ramazzotti", "price" : "9.90" },
    { "title" : "One night only", "artist" : "Bee Gees", "price" : "10.90" },
    { "title" : "Sylvias Mother", "artist" : "Dr.Hook", "price" : "8.10" }
   ]
}