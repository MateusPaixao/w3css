{
"customers":[
{
"CustomerName" : "Alfreds Futterkiste",
"City" : "Berlin",
"Country" : "Germany"
},
{
"CustomerName" : "Berglunds snabbköp",
"City" : "Luleå",
"Country" : "Sweden"
},
{
"CustomerName" : "Centro comercial Moctezuma",
"City" : "México D.F.",
"Country" : "Mexico"
},
{
"CustomerName" : "Ernst Handel",
"City" : "Graz",
"Country" : "Austria"
},
{
"CustomerName" : "FISSA Fabrica Inter. Salchichas S.A.",
"City" : "Madrid",
"Country" : "Spain"
},
{
"CustomerName" : "Galería del gastrónomo",
"City" : "Barcelona",
"Country" : "Spain"
},
{
"CustomerName" : "Island Trading",
"City" : "Cowes",
"Country" : "UK"
},
{
"CustomerName" : "Königlich Essen",
"City" : "Brandenburg",
"Country" : "Germany"
},
{
"CustomerName" : "Laughing Bacchus Wine Cellars",
"City" : "Vancouver",
"Country" : "Canada"
},
{
"CustomerName" : "Magazzini Alimentari Riuniti",
"City" : "Bergamo",
"Country" : "Italy"
},
{
"CustomerName" : "North/South",
"City" : "London",
"Country" : "UK"
},
{
"CustomerName" : "Paris spécialités",
"City" : "Paris",
"Country" : "France"
},
{
"CustomerName" : "Rattlesnake Canyon Grocery",
"City" : "Albuquerque",
"Country" : "USA"
},
{
"CustomerName" : "Simons bistro",
"City" : "København",
"Country" : "Denmark"
},
{
"CustomerName" : "The Big Cheese",
"City" : "Portland",
"Country" : "USA"
},
{
"CustomerName" : "Vaffeljernet",
"City" : "Århus",
"Country" : "Denmark"
},
{
"CustomerName" : "Wolski Zajazd",
"City" : "Warszawa",
"Country" : "Poland"
}
]}