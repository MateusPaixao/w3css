<!DOCTYPE html>
<html>
<body>

4.97<br>7.05<br>7.06
</body>
</html>