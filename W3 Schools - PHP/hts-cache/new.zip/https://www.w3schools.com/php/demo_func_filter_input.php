<!DOCTYPE html>
<html>
<body>

<form method="get" action="/php/demo_func_filter_input.php"> 
E-mail: <input type="text" name="email">
<input type="submit" name="submit" value="Submit"> 
</form>


</body>
</html>