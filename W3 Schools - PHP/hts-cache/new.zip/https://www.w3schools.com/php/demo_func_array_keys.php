<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Volvo
    [1] => BMW
    [2] => Toyota
)

</body>
</html>