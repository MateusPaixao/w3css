<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => green
    [1] => blue
)

</body>
</html>