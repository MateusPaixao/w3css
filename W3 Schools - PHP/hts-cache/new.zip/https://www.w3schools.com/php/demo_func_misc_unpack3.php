<!DOCTYPE html>
<html>
<body>

Array
(
    [chars1] => 52
    [chars2] => 120
    [int1] => 65
    [int2] => 66
)

</body>
</html>