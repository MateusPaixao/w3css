<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => Array
        (
            [0] => orange
        )

    [b] => Array
        (
            [0] => burgundy
            [1] => blue
        )

)

</body>
</html>