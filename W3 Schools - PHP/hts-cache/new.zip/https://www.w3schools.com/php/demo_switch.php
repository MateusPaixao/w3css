<!DOCTYPE html>
<html>
<body>

Your favorite color is red! 
</body>
</html>