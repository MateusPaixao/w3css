<!DOCTYPE html>
<html>
<body>

Volvo has 4 children.<br>BMW has 2 children.<br> 

</body>
</html>