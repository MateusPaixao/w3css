<!DOCTYPE html>
<html>
<body>

Total number of days: 40.<br>Total number of days: +40.<br>Month: 1, days: 9.
</body>
</html>