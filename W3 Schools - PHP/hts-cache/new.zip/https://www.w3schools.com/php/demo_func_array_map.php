<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => 1
    [1] => 4
    [2] => 9
    [3] => 16
    [4] => 25
)

</body>
</html>