<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Cat
    [1] => Dog
    [2] => Dog
)
Array
(
    [0] => Missy
    [1] => Fido
    [2] => Pluto
)

</body>
</html>