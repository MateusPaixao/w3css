<!DOCTYPE html>
<html>
<body>

I love W3Schools.com!
</body>
</html>