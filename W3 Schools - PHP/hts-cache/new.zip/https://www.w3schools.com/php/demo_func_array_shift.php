<!DOCTYPE html>
<html>
<body>

red<br>Array
(
    [b] => green
    [c] => blue
)

</body>
</html>