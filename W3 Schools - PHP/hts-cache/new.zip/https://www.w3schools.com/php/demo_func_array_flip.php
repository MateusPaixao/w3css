<!DOCTYPE html>
<html>
<body>

Array
(
    [red] => a
    [green] => b
    [blue] => c
    [yellow] => d
)

</body>
</html>