<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => yellow
)

</body>
</html>