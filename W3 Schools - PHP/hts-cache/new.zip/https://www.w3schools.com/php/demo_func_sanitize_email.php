<!DOCTYPE html>
<html>
<body>

john.doe@example.com 

</body>
</html>