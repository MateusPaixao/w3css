<!DOCTYPE html>
<html>
<body>

Easter Day is 26 days after March 21 this year.<br />Easter Day was 25 days after March 21 in 1990.<br />Easter Day was 10 days after March 21 in 1342.<br />Easter Day will be 20 days after March 21 in 2050.
</body>
</html>