<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => green
    [1] => blue
    [2] => purple
    [3] => red
    [4] => yellow
)

<p>Refresh the page to see how shuffle() randomizes the order of the elements in the array.</p>

</body>
</html>