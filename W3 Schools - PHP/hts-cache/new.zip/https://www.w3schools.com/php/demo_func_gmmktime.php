<!DOCTYPE html>
<html>
<body>

Oct 3, 1975 was on a Thursday
</body>
</html>