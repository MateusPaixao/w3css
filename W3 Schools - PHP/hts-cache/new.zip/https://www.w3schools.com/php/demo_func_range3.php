<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => a
    [1] => b
    [2] => c
    [3] => d
)

</body>
</html>