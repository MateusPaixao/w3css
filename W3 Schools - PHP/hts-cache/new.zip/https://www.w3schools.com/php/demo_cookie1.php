<!DOCTYPE html>
<html>
<body>

Cookie named 'user' is not set!
<p><strong>Note:</strong> You might have to reload the page to see the value of the cookie.</p>

</body>
</html>