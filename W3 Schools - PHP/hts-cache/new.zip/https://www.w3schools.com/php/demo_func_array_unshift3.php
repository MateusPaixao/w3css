<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => blue
    [1] => red
    [2] => green
)

</body>
</html>