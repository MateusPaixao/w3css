<!DOCTYPE html>
<html>
<body>

Favorite color is .<br>Favorite animal is .
</body>
</html>