<!DOCTYPE html>
<html>
<body>

Array
(
    [Peter] => 35
    [Ben] => 37
    [Joe] => 43
)

</body>
</html>