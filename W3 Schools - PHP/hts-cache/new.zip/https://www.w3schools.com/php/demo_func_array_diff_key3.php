<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => red
    [b] => green
)

</body>
</html>