<!DOCTYPE html>
<html>
<body>

Array
(
    [year] => 2013
    [month] => 5
    [day] => 1
    [hour] => 12
    [minute] => 30
    [second] => 45
    [fraction] => 0.5
    [warning_count] => 0
    [warnings] => Array
        (
        )

    [error_count] => 0
    [errors] => Array
        (
        )

    [is_localtime] => 
)

</body>
</html>