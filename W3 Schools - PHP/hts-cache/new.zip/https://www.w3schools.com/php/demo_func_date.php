<!DOCTYPE html>
<html>
<body>

Tuesday<br>Tuesday 18th of April 2017 02:34:47 PM<br>Oct 3,1975 was on a Friday<br>Tue, 18 Apr 17 14:34:47 -0400<br>1975-10-03T00:00:00-04:00
</body>
</html>