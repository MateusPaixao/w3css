<!DOCTYPE html>
<html>
<body>

Array
(
    [b] => green
)

</body>
</html>