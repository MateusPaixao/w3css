<!DOCTYPE html>
<html>
<body>

Cookie 'user' is set!<br>Value is: deleted
<p><strong>Note:</strong> You might have to relaod the page to see the value of the cookie.</p>

</body>
</html>