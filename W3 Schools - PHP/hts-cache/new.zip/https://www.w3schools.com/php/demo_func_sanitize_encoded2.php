<!DOCTYPE html>
<html>
<body>

https%3A%2F%2Fwww.w3schools.com 

</body>
</html>