<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => red
    [1] => green
    [2] => yellow
    [3] => purple
    [4] => blue
)

<p>Refresh the page to see how shuffle() randomizes the order of the elements in the array.</p>

</body>
</html>