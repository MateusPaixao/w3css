<!DOCTYPE html>
<html>
<body>

1.6666666666667  

</body>
</html>