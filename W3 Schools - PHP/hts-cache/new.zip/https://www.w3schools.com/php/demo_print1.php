<!DOCTYPE html>
<html>
<body>

<h2>PHP is Fun!</h2>Hello world!<br>I'm about to learn PHP! 

</body>
</html>