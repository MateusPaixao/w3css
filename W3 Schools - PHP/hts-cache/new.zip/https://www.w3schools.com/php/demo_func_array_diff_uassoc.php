<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => red
    [c] => blue
)

</body>
</html>