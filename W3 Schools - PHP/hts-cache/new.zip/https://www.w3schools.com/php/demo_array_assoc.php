<!DOCTYPE html>
<html>
<body>

Peter is 35 years old.
</body>
</html>