<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => Array
        (
            [0] => yellow
        )

    [b] => Array
        (
            [0] => black
            [1] => blue
        )

)

</body>
</html>