<!DOCTYPE html>
<html>
<body>

Key=Ben, Value=37<br>Key=Joe, Value=43<br>Key=Peter, Value=35<br>
</body>
</html>