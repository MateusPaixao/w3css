<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => different
    [1] => same
    [2] => different
)

</body>
</html>