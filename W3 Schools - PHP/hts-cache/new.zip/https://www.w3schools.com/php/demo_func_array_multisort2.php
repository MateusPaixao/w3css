<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Cat
    [1] => Dog
)
Array
(
    [0] => Missy
    [1] => Fido
)

</body>
</html>