<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Peter
    [1] => 41
    [2] => USA
)

</body>
</html>