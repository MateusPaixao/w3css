<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => red
    [1] => green
)

</body>
</html>