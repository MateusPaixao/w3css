<!DOCTYPE html>
<html>
<body>

Array
(
    [c] => blue
    [d] => yellow
)

</body>
</html>