<!DOCTYPE html>
<html>
<body>

Today is 2017/04/18<br>Today is 2017.04.18<br>Today is 2017-04-18<br>Today is Tuesday
</body>
</html>