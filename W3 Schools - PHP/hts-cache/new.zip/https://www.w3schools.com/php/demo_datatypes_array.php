<!DOCTYPE html>
<html>
<body>

array(3) {
  [0]=>
  string(5) "Volvo"
  [1]=>
  string(3) "BMW"
  [2]=>
  string(6) "Toyota"
}
  

</body>
</html>