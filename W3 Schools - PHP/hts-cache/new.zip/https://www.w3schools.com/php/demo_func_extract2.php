<!DOCTYPE html>
<html>
<body>

$a = Original; $b = Dog; $c = Horse; $dup_a = Cat
</body>
</html>