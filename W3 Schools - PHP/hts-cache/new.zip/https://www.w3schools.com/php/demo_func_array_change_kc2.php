<!DOCTYPE html>
<html>
<body>

Array
(
    [peter] => 35
    [ben] => 37
    [joe] => 43
)

</body>
</html>