<!DOCTYPE html>
<html>
<body>

Array
(
    [c] => Toyota
    [b] => BMW
    [a] => Volvo
)

</body>
</html>