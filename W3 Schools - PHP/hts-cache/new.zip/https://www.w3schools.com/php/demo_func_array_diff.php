<!DOCTYPE html>
<html>
<body>

Array
(
    [d] => yellow
)

</body>
</html>