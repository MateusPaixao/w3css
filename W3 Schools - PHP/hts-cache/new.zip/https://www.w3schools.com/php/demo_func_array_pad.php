<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => red
    [1] => green
    [2] => blue
    [3] => blue
    [4] => blue
)

</body>
</html>