<!DOCTYPE html>
<html>
<body>

<h2>PHP is Fun!</h2>Hello world!<br>I'm about to learn PHP!<br>This string was made with multiple parameters. 

</body>
</html>