<!DOCTYPE html>
<html>
<body>

0.14112000805987<br>-0.14112000805987<br>0<br>1.2246467991474E-16<br>1
</body>
</html>