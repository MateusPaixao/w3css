<!DOCTYPE html>
<html>
<body>

Array
(
    [year] => 
    [month] => 12
    [day] => 13
    [hour] => 
    [minute] => 
    [second] => 
    [fraction] => 
    [warning_count] => 0
    [warnings] => Array
        (
        )

    [error_count] => 1
    [errors] => Array
        (
            [8] => Data missing
        )

    [is_localtime] => 
)
<br><br>Array
(
    [year] => 2013
    [month] => 5
    [day] => 12
    [hour] => 14
    [minute] => 35
    [second] => 0
    [fraction] => 
    [warning_count] => 0
    [warnings] => Array
        (
        )

    [error_count] => 0
    [errors] => Array
        (
        )

    [is_localtime] => 1
    [zone_type] => 1
    [zone] => -120
    [is_dst] => 
)

</body>
</html>