<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => red
    [b] => yellow
    [c] => blue
)

</body>
</html>