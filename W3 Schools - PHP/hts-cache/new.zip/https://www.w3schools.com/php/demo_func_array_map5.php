<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Array
        (
            [0] => Dog
            [1] => Puppy
        )

    [1] => Array
        (
            [0] => Cat
            [1] => Kitten
        )

)

</body>
</html>