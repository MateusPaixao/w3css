<!DOCTYPE html>
<html>
<body>

Array
(
    [1] => Peter
    [value] => Peter
    [0] => 0
    [key] => 0
)

</body>
</html>