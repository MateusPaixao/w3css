<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>  


<h2>PHP Form Validation Example</h2>
<form method="post" action="/php/demo_form_validation_escapechar.php">  
  Name: <input type="text" name="name">
  <br><br>
  E-mail: <input type="text" name="email">
  <br><br>
  Website: <input type="text" name="website">
  <br><br>
  Comment: <textarea name="comment" rows="5" cols="40"></textarea>
  <br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form>

<h2>Your Input:</h2><br><br><br><br>
</body>
</html>