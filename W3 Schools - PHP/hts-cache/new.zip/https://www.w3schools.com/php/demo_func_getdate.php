<!DOCTYPE html>
<html>
<body>

Array
(
    [seconds] => 51
    [minutes] => 38
    [hours] => 11
    [mday] => 18
    [wday] => 2
    [mon] => 4
    [year] => 2017
    [yday] => 107
    [weekday] => Tuesday
    [month] => April
    [0] => 1492529931
)
<br><br>Tuesday, April 18, 2017
</body>
</html>