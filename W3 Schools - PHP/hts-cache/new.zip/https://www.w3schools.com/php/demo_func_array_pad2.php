<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => blue
    [1] => blue
    [2] => blue
    [3] => red
    [4] => green
)

</body>
</html>