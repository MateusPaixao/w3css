<!DOCTYPE html>
<html>
<body>

0.87629806116834<br>1.9823131728624<br>1.5707963267949<br>3.1415926535898<br>0<br>NAN
</body>
</html>