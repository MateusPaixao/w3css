<!DOCTYPE html>
<html>
<body>

Standard sorting: Array
(
    [0] => temp1.txt
    [1] => temp10.txt
    [2] => temp15.txt
    [3] => temp2.txt
    [4] => temp22.txt
)
<br>Natural order: Array
(
    [0] => temp1.txt
    [3] => temp2.txt
    [1] => temp10.txt
    [2] => temp15.txt
    [4] => temp22.txt
)

</body>
</html>