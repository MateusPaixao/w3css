<!DOCTYPE html>
<html>
<body>

2<br>-2<br>1<br>-1<br>2<br>-2<br>1<br>-1
</body>
</html>