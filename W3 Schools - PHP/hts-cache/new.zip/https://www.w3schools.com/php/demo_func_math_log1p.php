<!DOCTYPE html>
<html>
<body>

1.3132665745863<br>1.0986122886681<br>0.69314718055995<br>0
</body>
</html>