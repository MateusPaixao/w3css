<!DOCTYPE html>
<html>
<body>

Array
(
    [A] => Cat
    [B] => Bird
    [C] => Horse
)

</body>
</html>