<!DOCTYPE html>
<html>
<body>

$a = Cat; $b = Dog; $c = Horse
</body>
</html>