<!DOCTYPE html>
<html>
<body>

0.69449826562656<br>-0.41151684606749<br>0<br>-1.5707963267949<br>1.5707963267949<br>NAN
</body>
</html>