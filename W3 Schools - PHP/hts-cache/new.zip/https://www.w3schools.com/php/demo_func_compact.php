<!DOCTYPE html>
<html>
<body>

Array
(
    [firstname] => Peter
    [lastname] => Griffin
    [age] => 41
)

</body>
</html>