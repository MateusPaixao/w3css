<!DOCTYPE html>
<html>
<body>

My first PHP script! 

</body>
</html>