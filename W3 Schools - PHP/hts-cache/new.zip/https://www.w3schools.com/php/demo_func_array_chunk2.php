<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Array
        (
            [Peter] => 35
            [Ben] => 37
        )

    [1] => Array
        (
            [Joe] => 43
            [Harry] => 50
        )

)

</body>
</html>