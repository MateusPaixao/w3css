<!DOCTYPE html>
<html>
<body>

0.43429738512451<br>0.30102999566398<br>0<br>-INF
</body>
</html>