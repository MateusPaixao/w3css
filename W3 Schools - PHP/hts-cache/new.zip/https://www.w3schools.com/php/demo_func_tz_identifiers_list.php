<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Africa/Abidjan
    [1] => Africa/Accra
    [2] => Africa/Addis_Ababa
    [3] => Africa/Algiers
    [4] => Africa/Asmara
    [5] => Africa/Bamako
    [6] => Africa/Bangui
    [7] => Africa/Banjul
    [8] => Africa/Bissau
    [9] => Africa/Blantyre
    [10] => Africa/Brazzaville
    [11] => Africa/Bujumbura
    [12] => Africa/Cairo
    [13] => Africa/Casablanca
    [14] => Africa/Ceuta
    [15] => Africa/Conakry
    [16] => Africa/Dakar
    [17] => Africa/Dar_es_Salaam
    [18] => Africa/Djibouti
    [19] => Africa/Douala
    [20] => Africa/El_Aaiun
    [21] => Africa/Freetown
    [22] => Africa/Gaborone
    [23] => Africa/Harare
    [24] => Africa/Johannesburg
    [25] => Africa/Juba
    [26] => Africa/Kampala
    [27] => Africa/Khartoum
    [28] => Africa/Kigali
    [29] => Africa/Kinshasa
    [30] => Africa/Lagos
    [31] => Africa/Libreville
    [32] => Africa/Lome
    [33] => Africa/Luanda
    [34] => Africa/Lubumbashi
    [35] => Africa/Lusaka
    [36] => Africa/Malabo
    [37] => Africa/Maputo
    [38] => Africa/Maseru
    [39] => Africa/Mbabane
    [40] => Africa/Mogadishu
    [41] => Africa/Monrovia
    [42] => Africa/Nairobi
    [43] => Africa/Ndjamena
    [44] => Africa/Niamey
    [45] => Africa/Nouakchott
    [46] => Africa/Ouagadougou
    [47] => Africa/Porto-Novo
    [48] => Africa/Sao_Tome
    [49] => Africa/Tripoli
    [50] => Africa/Tunis
    [51] => Africa/Windhoek
)

</body>
</html>