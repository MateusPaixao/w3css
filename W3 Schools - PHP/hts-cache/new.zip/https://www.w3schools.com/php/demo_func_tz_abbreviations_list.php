<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Array
        (
            [dst] => 
            [offset] => -18000
            [timezone_id] => America/Porto_Acre
        )

    [1] => Array
        (
            [dst] => 
            [offset] => -18000
            [timezone_id] => America/Eirunepe
        )

    [2] => Array
        (
            [dst] => 
            [offset] => -18000
            [timezone_id] => America/Rio_Branco
        )

    [3] => Array
        (
            [dst] => 
            [offset] => -18000
            [timezone_id] => Brazil/Acre
        )

)

</body>
</html>