<!DOCTYPE html>
<html>
<body>

Volvo: Ordered: 100. Sold: 96<br>BMW: Ordered: 60. Sold: 59<br>Toyota: Ordered: 110. Sold: 100<br>
</body>
</html>