<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => red
    [0] => yellow
)

</body>
</html>