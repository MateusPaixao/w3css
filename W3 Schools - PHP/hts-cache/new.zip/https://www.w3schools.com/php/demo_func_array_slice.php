<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => blue
    [1] => yellow
    [2] => brown
)

</body>
</html>