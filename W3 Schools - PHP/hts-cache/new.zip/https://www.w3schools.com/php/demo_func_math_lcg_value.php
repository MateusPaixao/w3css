<!DOCTYPE html>
<html>
<body>

0.31844494009365<br>0.012163238465762
</body>
</html>