<!DOCTYPE html>
<html>
<body>

<code><span style="color: #000000">
&lt;html&gt;<br />&lt;body&gt;<br /><span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;(</span><span style="color: #DD0000">"test.php"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;<br /></span>&lt;/body&gt;<br />&lt;/html&gt;</span>
</code>
</body>
</html>