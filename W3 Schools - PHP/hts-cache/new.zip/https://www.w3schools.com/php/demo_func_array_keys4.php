<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => 3
)

</body>
</html>