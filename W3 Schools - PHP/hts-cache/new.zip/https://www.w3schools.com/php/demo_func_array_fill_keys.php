<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => blue
    [b] => blue
    [c] => blue
    [d] => blue
)

</body>
</html>