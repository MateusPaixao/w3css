<!DOCTYPE html>
<html>
<body>

<p>Variable x inside function is: 5</p><p>Variable x outside function is: </p>
</body>
</html>