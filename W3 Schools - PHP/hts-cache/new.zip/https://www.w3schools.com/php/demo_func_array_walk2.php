<!DOCTYPE html>
<html>
<body>

a has the value red<br>b has the value green<br>c has the value blue<br>
</body>
</html>