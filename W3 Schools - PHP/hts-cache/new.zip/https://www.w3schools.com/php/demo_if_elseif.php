<!DOCTYPE html>
<html>
<body>

<p>The hour (of the server) is 12, and will give the following message:</p>Have a good day! 
</body>
</html>