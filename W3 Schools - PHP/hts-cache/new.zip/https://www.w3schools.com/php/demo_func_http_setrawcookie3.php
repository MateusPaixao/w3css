<!DOCTYPE html>

<html>
<body>

Cookie named 'user' does not exist!
</body>
</html>