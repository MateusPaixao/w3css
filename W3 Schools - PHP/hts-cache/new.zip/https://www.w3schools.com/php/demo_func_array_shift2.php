<!DOCTYPE html>
<html>
<body>

red<br>Array
(
    [0] => green
    [1] => blue
)

</body>
</html>