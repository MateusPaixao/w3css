<!DOCTYPE html>
<html>
<body>

Mozilla/5.0 (Linux; U; Android 4.4.2; en-US; Everfancy III Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11.2.0.915 U3/0.8.0 Mobile Safari/534.30 X-Middleton/1
</body>
</html>