<!DOCTYPE html>
<html>
<body>

Array
(
    [b] => green
    [c] => blue
)
Array
(
    [0] => green
    [1] => blue
)

</body>
</html>