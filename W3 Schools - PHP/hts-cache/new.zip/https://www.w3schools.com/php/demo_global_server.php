<!DOCTYPE html>
<html>
<body>

/php/demo_global_server.php<br>www.w3schools.com<br>www.w3schools.com<br>https://www.w3schools.com/php/showphp.asp?filename=demo_global_server<br>Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36 X-Middleton/1<br>/php/demo_global_server.php
</body>
</html>