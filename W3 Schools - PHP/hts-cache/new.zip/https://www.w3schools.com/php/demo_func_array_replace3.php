<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => orange
    [0] => green
    [b] => burgundy
)

</body>
</html>