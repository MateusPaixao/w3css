<!DOCTYPE html>
<html>
<body>

22<br>11<br>6<br>4<br>2<br>
</body>
</html>