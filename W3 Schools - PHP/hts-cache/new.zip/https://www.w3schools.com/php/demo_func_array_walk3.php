<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => yellow
    [b] => yellow
    [c] => yellow
)

</body>
</html>