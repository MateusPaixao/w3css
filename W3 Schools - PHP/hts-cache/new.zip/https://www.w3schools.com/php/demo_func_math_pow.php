<!DOCTYPE html>
<html>
<body>

16<br>16<br>0.0625<br>NAN
</body>
</html>