<!DOCTYPE html>
<html>
<body>

Array
(
    [country_code] => TW
    [latitude] => 25.05
    [longitude] => 121.5
    [comments] => 
)

</body>
</html>