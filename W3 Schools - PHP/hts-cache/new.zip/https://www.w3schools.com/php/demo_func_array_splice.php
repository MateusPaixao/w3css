<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => purple
    [1] => orange
    [c] => blue
    [d] => yellow
)

</body>
</html>