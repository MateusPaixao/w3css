<!DOCTYPE html>
<html>
<body>

Peter<br>Joe<br>Joe<br>Peter<br>Cleveland<br>Glenn<br>Glenn<br>Peter<br>Joe<br><br>Array
(
    [1] => Joe
    [value] => Joe
    [0] => 1
    [key] => 1
)

</body>
</html>