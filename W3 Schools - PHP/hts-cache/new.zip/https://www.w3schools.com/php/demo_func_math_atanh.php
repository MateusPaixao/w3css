<!DOCTYPE html>
<html>
<body>

1.0593061708232<br>0.54930614433405<br>-0.54930614433405<br>INF<br>-INF
</body>
</html>