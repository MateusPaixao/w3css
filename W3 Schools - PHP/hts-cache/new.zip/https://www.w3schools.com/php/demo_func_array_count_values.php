<!DOCTYPE html>
<html>
<body>

Array
(
    [A] => 2
    [Cat] => 1
    [Dog] => 2
)

</body>
</html>