<!DOCTYPE html>
<html>
<body>

-0.98999249660045<br>-0.98999249660045<br>1<br>-1<br>1
</body>
</html>