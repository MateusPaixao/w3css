<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => red
    [1] => purple
    [2] => orange
    [3] => green
)

</body>
</html>