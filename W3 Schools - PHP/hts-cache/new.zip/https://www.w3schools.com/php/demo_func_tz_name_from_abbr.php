<!DOCTYPE html>
<html>
<body>

America/New_York<br>Europe/Helsinki
</body>
</html>