<!DOCTYPE html>
<html>
<body>

Array
(
    [1] => 80
    [2] => 72
    [3] => 80
)

</body>
</html>