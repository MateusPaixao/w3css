<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => red
)

</body>
</html>