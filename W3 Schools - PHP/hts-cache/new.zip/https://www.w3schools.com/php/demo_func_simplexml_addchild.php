<!DOCTYPE html>
<html>
<body>

<?xml version="1.0"?>
<note>
<to>Tove</to>
<from>Jani</from>
<heading>Reminder</heading>
<body>Don't forget me this weekend!<date>2014-01-01</date></body>
<footer>Some footer text</footer></note>

<p>Select View Source to see the added date element (inside the body element) and the new footer element.</p>

</body>
</html>