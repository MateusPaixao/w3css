<!DOCTYPE html>
<html>
<body>

The key a has the value red<br>The key b has the value green<br>The key c has the value blue<br>
</body>
</html>