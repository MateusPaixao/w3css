<!DOCTYPE html>
<html>
<body>

Array
(
    [c] => blue
)

</body>
</html>