<!DOCTYPE html>
<html>
<body>

Tuesday<br>Tuesday 18th of April 2017 04:35:06 PM<br>Oct 3, 1975 was on a Friday<br>Tue, 18 Apr 17 16:35:06 +0000<br>1975-10-03T04:00:00+00:00
</body>
</html>