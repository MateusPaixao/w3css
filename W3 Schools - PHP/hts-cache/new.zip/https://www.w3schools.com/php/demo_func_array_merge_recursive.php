<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => red
    [b] => Array
        (
            [0] => green
            [1] => yellow
        )

    [c] => blue
)

</body>
</html>