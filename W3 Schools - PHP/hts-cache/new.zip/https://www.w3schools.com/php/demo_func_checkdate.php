<!DOCTYPE html>
<html>
<body>

bool(false)
<br>bool(false)
<br>bool(true)

</body>
</html>