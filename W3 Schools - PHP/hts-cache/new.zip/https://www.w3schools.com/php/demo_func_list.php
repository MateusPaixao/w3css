<!DOCTYPE html>
<html>
<body>

I have several animals, a Dog, a Cat and a Horse.
</body>
</html>