<!DOCTYPE html>
<html>
<body>

Array
(
    [PETER] => 35
    [BEN] => 37
    [JOE] => 43
)

</body>
</html>