<!DOCTYPE html>
<html>
<body>

1.000006684914<br>0.69314718055995<br>0<br>-INF
</body>
</html>