<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => blue
    [a] => red
    [b] => green
)

</body>
</html>