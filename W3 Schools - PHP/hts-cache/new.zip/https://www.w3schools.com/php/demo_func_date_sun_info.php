<!DOCTYPE html>
<html>
<body>

<h3>Date: 1st January, 2013</h3>sunrise: 23:39:11<br>sunset: 09:46:51<br>transit: 04:43:01<br>civil_twilight_begin: 23:12:29<br>civil_twilight_end: 10:13:33<br>nautical_twilight_begin: 22:42:09<br>nautical_twilight_end: 10:43:53<br>astronomical_twilight_begin: 22:12:28<br>astronomical_twilight_end: 11:13:34<br><h3>Date: 1st June, 2013</h3>sunrise: 22:34:03<br>sunset: 12:39:59<br>transit: 05:37:01<br>civil_twilight_begin: 22:06:21<br>civil_twilight_end: 13:07:40<br>nautical_twilight_begin: 21:32:35<br>nautical_twilight_end: 13:41:27<br>astronomical_twilight_begin: 20:56:19<br>astronomical_twilight_end: 14:17:42<br>
</body>
</html>