<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Toyota
)

</body>
</html>