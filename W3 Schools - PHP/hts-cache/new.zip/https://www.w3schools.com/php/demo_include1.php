<!DOCTYPE html>
<html>
<body>

<h1>Welcome to my home page!</h1>
<p>Some text.</p>
<p>Some more text.</p>
<p>Copyright &copy; 1999-2017 W3Schools.com</p>
</body>
</html>