<!DOCTYPE html>
<html>
<body>

Array
(
    [c] => https://w3schools.com/ns
)
 

</body>
</html>