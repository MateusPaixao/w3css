<!DOCTYPE html>
<html>
<body>

Array
(
    [Animal] => HORSE
    [Type] => MAMMAL
)

</body>
</html>