<!DOCTYPE html>
<html>
<body>

<code><span style="color: #000000">
Hello&nbsp;world!&nbsp;<span style="color: #0000BB">&lt;?php&nbsp;phpinfo</span><span style="color: #007700">();&nbsp;</span><span style="color: #0000BB">?&gt;</span>
</span>
</code>
</body>
</html>