<!DOCTYPE html>
<html>
<body>

66.8
</body>
</html>