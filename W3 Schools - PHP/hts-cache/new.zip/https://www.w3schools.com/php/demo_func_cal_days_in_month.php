<!DOCTYPE html>
<html>
<body>

There was 28 days in February 1965.<br>There was 29 days in February 2004.
</body>
</html>