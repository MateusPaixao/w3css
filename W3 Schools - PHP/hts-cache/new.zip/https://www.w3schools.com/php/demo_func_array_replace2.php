<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => orange
    [b] => green
    [0] => burgundy
)

</body>
</html>