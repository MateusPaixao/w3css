<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Volvo
    [1] => XC90
    [2] => Array
        (
            [0] => BMW
            [1] => Toyota
        )

)
Array
(
    [0] => Array
        (
            [0] => BMW
            [1] => Toyota
        )

    [1] => XC90
    [2] => Volvo
)
Array
(
    [2] => Array
        (
            [0] => BMW
            [1] => Toyota
        )

    [1] => XC90
    [0] => Volvo
)

</body>
</html>