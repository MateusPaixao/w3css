<!DOCTYPE html>
<html>
<body>

6.7<br>6.7<br>3<br>3
</body>
</html>