<!DOCTYPE html>
<html>
<body>

The key from the current position is: 0
</body>
</html>