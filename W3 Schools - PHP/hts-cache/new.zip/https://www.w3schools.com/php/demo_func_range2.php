<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => 0
    [1] => 10
    [2] => 20
    [3] => 30
    [4] => 40
    [5] => 50
)

</body>
</html>