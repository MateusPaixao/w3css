<!DOCTYPE html>
<html>
<body>

Array
(
    [1] => green
    [2] => blue
)
Array
(
    [0] => green
    [1] => blue
)

</body>
</html>