<!DOCTYPE html>
<html>
<body>

Array
(
    [3] => yellow
)

</body>
</html>