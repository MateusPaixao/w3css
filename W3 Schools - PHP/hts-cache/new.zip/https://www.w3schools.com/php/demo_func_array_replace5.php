<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => orange
    [1] => green
    [2] => blue
    [3] => burgundy
)

</body>
</html>