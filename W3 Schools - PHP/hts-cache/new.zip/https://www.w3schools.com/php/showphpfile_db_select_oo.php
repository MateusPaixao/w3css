<!DOCTYPE html>
<html>
<body>

id: 1 - Name: John Doe<br>
id: 2 - Name: Mary Moe<br>
id: 3 - Name: Julie Dooley<br>

</body>
</html>