<!DOCTYPE html>
<html>
<body>

SimpleXMLElement Object
(
    [to] => Tove
    [from] => Jani
    [heading] => Reminder
    [body] => Don't forget me this weekend!
)

</body>
</html>