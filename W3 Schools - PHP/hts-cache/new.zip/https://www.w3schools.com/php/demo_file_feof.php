<!DOCTYPE html>
<html>
<body>

AJAX = Asynchronous JavaScript and XML
<br>CSS = Cascading Style Sheets
<br>HTML = Hyper Text Markup Language
<br>PHP = PHP Hypertext Preprocessor
<br>SQL = Structured Query Language
<br>SVG = Scalable Vector Graphics
<br>XML = EXtensible Markup Language<br>
</body>
</html>