<!DOCTYPE html>
<html>
<body>

Array
(
    [warning_count] => 1
    [warnings] => Array
        (
            [6] => Double timezone specification
        )

    [error_count] => 5
    [errors] => Array
        (
            [0] => The timezone could not be found in the database
            [10] => Unexpected character
            [11] => Unexpected character
            [12] => Unexpected character
            [13] => Unexpected character
        )

)

</body>
</html>