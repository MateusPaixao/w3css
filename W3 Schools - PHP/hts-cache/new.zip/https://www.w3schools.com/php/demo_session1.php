<!DOCTYPE html>
<html>
<body>

Session variables are set.
</body>
</html>