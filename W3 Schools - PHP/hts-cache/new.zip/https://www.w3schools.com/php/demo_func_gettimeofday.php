<!DOCTYPE html>
<html>
<body>

Array
(
    [sec] => 1492537721
    [usec] => 177185
    [minuteswest] => 240
    [dsttime] => 1
)
<br><br>1492537721.1773<br><br>1492537721.177282
</body>
</html>