<!DOCTYPE html>
<html>
<body>

Asia/Bangkok
</body>
</html>