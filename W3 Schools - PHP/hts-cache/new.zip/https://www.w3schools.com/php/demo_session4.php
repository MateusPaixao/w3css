<!DOCTYPE html>
<html>
<body>

Array
(
    [favcolor] => yellow
)

</body>
</html>