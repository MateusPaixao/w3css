<!DOCTYPE html>
<html>
<body>

Array
(
    [date] => 6/20/2007
    [month] => 6
    [day] => 20
    [year] => 2007
    [dow] => 3
    [abbrevdayname] => Wed
    [dayname] => Wednesday
    [abbrevmonth] => Jun
    [monthname] => June
)

</body>
</html>