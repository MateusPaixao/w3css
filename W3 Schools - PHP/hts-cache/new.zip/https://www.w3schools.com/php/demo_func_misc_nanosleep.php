<!DOCTYPE html>
<html>
<body>

Slept for three and a half a second
</body>
</html>