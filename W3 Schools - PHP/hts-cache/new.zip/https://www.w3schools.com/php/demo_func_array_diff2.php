<!DOCTYPE html>
<html>
<body>

Array
(
    [b] => green
    [c] => blue
)

</body>
</html>