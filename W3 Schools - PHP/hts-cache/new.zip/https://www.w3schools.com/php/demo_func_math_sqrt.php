<!DOCTYPE html>
<html>
<body>

0<br>1<br>3<br>0.8<br>NAN
</body>
</html>