<!DOCTYPE html>
<html>
<body>

<?xml version="1.0"?>
<note type="private">
<to>Tove</to>
<from>Jani</from>
<heading>Reminder</heading>
<body date="2014-01-01">Don't forget me this weekend!</body>
</note>

<p>Select View Source to see the added "type" attribute (added to the note element), and the "date" attribute (added to the body element).</p>

</body>
</html>