<!DOCTYPE html>
<html>
<body>

Variable is an integer
</body>
</html>