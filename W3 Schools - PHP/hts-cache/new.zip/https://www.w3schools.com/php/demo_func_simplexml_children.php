<!DOCTYPE html>
<html>
<body>

Child node: Tove<br>Child node: Jani<br>Child node: Reminder<br>Child node: Don't forget me this weekend!<br> 
 
</body>
</html>