<!DOCTYPE html>
<html>
<body>

Array
(
    [3] => blue
    [4] => blue
    [5] => blue
    [6] => blue
)
<br>Array
(
    [0] => red
)

</body>
</html>