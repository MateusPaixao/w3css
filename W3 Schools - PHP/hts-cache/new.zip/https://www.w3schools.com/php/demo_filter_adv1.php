<!DOCTYPE html>
<html>
<body>

Variable value is within the legal range
</body>
</html>