<!DOCTYPE html>
<html>
<body>

array(1) {
  ["c"]=>
  string(24) "https://w3schools.com/ns"
}
 

</body>
</html>