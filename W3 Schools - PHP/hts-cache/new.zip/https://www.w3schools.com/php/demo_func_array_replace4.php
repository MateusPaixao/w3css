<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => orange
    [1] => burgundy
)

</body>
</html>