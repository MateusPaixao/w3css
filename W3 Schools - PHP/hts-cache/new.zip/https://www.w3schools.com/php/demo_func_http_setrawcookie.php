<!DOCTYPE html>
<html>
<body>

Cookie is set.
</body>
</html>