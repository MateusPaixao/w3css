<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => red
    [b] => green
    [c] => blue
)

</body>
</html>