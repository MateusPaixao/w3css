<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Bear
    [1] => Cat
    [2] => Dog
    [3] => Horse
    [4] => Zebra
)

</body>
</html>