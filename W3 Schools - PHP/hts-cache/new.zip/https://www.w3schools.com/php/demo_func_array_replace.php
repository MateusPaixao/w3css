<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => blue
    [1] => yellow
)

</body>
</html>