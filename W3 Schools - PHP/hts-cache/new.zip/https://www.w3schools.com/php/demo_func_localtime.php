<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => 7
    [1] => 17
    [2] => 13
    [3] => 18
    [4] => 3
    [5] => 117
    [6] => 2
    [7] => 107
    [8] => 1
)
<br><br>Array
(
    [tm_sec] => 7
    [tm_min] => 17
    [tm_hour] => 13
    [tm_mday] => 18
    [tm_mon] => 3
    [tm_year] => 117
    [tm_wday] => 2
    [tm_yday] => 107
    [tm_isdst] => 1
)

</body>
</html>