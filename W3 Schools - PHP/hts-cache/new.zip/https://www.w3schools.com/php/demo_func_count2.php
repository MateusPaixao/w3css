<!DOCTYPE html>
<html>
<body>

Normal count: 3<br>Recursive count: 8
</body>
</html>