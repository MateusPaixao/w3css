<!DOCTYPE html>
<html>
<body>

The key a has the value red<br>The key b has the value green<br>The key 1 has the value blue<br>The key 2 has the value yellow<br>
</body>
</html>