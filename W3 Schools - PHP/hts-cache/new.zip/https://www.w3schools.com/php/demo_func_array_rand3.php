<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => a
    [1] => c
)

</body>
</html>