<!DOCTYPE html>
<html>
<body>

Array
(
    [myint1] => 80
    [myint2] => 72
    [myint3] => 80
)

</body>
</html>