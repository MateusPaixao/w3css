<!DOCTYPE html>
<html>
<body>

Key=a, Value=4<br>Key=b, Value=2<br>Key=c, Value=8<br>Key=d, Value=6<br>
</body>
</html>