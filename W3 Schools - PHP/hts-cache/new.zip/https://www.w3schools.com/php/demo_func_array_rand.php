<!DOCTYPE html>
<html>
<body>

red<br>yellow<br>brown
</body>
</html>