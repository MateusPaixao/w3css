<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => red
    [b] => green
    [0] => blue
    [1] => yellow
)

</body>
</html>