<!DOCTYPE html>
<html>
<body>

Here I only use the Dog and Horse variables.
</body>
</html>