<!DOCTYPE html>
<html>
<body>

https%3A%2F%2Fwww.w3schools%C5%C5.com 

</body>
</html>