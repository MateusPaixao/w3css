<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Horse
    [1] => Fido
    [2] => Cat
)

</body>
</html>