<!DOCTYPE html>
<html>
<body>

Oct 3, 1975 was on a Friday<br><br>Jan-05-2002<br>Feb-01-2002<br>Jan-01-2001<br>Jan-01-1999<br>
</body>
</html>