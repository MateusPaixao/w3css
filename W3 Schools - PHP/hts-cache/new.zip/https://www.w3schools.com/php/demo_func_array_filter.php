<!DOCTYPE html>
<html>
<body>

Array
(
    [3] => 3
)

</body>
</html>