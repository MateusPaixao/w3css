<!DOCTYPE html>
<html>
<body>

Array
(
    [a] => red
    [b] => green
    [c] => blue
    [d] => yellow
)
  

</body>
</html>