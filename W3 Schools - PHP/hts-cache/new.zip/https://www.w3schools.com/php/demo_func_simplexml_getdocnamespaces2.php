<!DOCTYPE html>
<html>
<body>

array(2) {
  ["c"]=>
  string(24) "https://w3schools.com/ns"
  ["a"]=>
  string(29) "https://w3schools.com/country"
}
 

</body>
</html>