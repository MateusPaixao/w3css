<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => 0
    [1] => 3
)

</body>
</html>